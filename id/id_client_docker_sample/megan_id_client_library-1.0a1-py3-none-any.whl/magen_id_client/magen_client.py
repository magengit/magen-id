from functools import wraps

from flask import redirect,session
from flask import url_for

#from werkzeug import cached_property

from flask import request, Response

from urllib.parse import urlsplit, urlunsplit

from magen_id_client.magen_client_handler import MagenClientAppHandler


__author__ = "michowdh@cisco.com"
__copyright__ = "Copyright(c) 2015, Cisco Systems, Inc."
__version__ = "0.2"
__status__ = "alpha"


class Params(object):
    pass

#logger = logging.getLogger(__name__)

#remove all print TODO

class MagenClient(object):
    """This is MagenClient to secure services.
        This server provides an authorize handler and a token hander,
        Like many other Flask extensions, there are two usage modes. One is
        binding the Flask app instance::
            app = Flask(__name__)
            oid = MagenClient(app)
    """


    def __init__(self, app=None):
        self.remote_apps = {}
        self.app = app
        if app:
            self.init_app(app)

    def init_app(self, app):
        self.params = Params()
        self.app = app

    def register_client_app(self, name, register=True, **kwargs):

        remote = MagenClientAppHandler(name, **kwargs)
        if register:
            assert name not in self.remote_apps
            self.remote_apps[name] = remote
        return remote



    def error_uri(self):
        error_uri = self.app.config.get('CLIENT_ERROR_URI')
        if error_uri:
            return error_uri
        error_endpoint = self.app.config.get('CLIENT_ERROR_ENDPOINT')
        if error_endpoint:
            return url_for(error_endpoint)
        return '/oauth/errors'




    def tokensetter(self, f):
        self._tokensetter = f
        return f