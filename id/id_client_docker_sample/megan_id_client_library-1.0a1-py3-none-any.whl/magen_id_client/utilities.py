import base64
import logging, traceback
import uuid
import datetime

import time
import os
import re
import json

from werkzeug.security import check_password_hash, gen_salt

from urllib.parse import urlparse

from Crypto.PublicKey.RSA import importKey
import jwt

from flask import request, Response

__author__ = "michowdh@cisco.com"
__copyright__ = "Copyright(c) 2015, Cisco Systems, Inc."
__version__ = "0.2"
__status__ = "alpha"


class Utilities(object):

  @staticmethod
  def get_the_encoded_url(str):
    o = urlparse(str)
    return o.geturl()


  @staticmethod
  def randomstr(string_length=40):
    random = str(uuid.uuid4())
    random = random.upper()
    random = random.replace("-", "")
    return random[0:string_length]
