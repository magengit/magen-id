magen_id_client package
=================

Submodules
----------

magen_id_client.magen_client module
---------------------------------

.. automodule:: magen_id_client.magen_client
    :members:
    :undoc-members:
    :show-inheritance:

magen_id_client.magen_client_handler module
------------------------------------

.. automodule:: magen_id_client.magen_client_handler
    :members:
    :undoc-members:
    :show-inheritance:

magen_id_client.oic_client_utilities module
--------------------------------

.. automodule:: magen_id_client.oic_client_utilities
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: magen_id_client
    :members:
    :undoc-members:
    :show-inheritance: